function showLoading() {
    $('#loading-spinner').css('display', 'block');
}

function hideLoading() {
    $('#loading-spinner').css('display', 'none');
}

function displayPosts(posts) {
    posts.forEach(post => {
        const postHtml = `
            <div class="post" data-post-id="${post.id}" data-comments-loaded="false">
                <h3>${post.title}</h3>
                <p><strong>ID:</strong> ${post.id}</p>
                <p><strong>User ID:</strong> ${post.userId}</p>
                <p>${post.body}</p>
                <button class="load-comments">Carregar Comentários</button>
                <div class="comments"></div>
            </div>
        `;
        $('#posts-container').append(postHtml);
    });
}

function loadPosts() {
    showLoading();
    $.ajax({
        url: 'https://jsonplaceholder.typicode.com/posts',
        method: 'GET',
        success: function(data) {
            displayPosts(data);
        },
        error: function() {
            alert('Erro ao carregar os posts.');
        },
        complete: function() {
            hideLoading();
        }
    });
}

function loadComments(postId, commentsContainer) {
    showLoading();
    fetch(`https://jsonplaceholder.typicode.com/comments?postId=${postId}`)
        .then(response => response.json())
        .then(comments => {
            comments.forEach(comment => {
                const commentHtml = `
                    <div class="comment">
                        <p><strong>${comment.name}</strong> (${comment.email})</p>
                        <p>${comment.body}</p>
                    </div>
                `;
                commentsContainer.append(commentHtml);
            });
            commentsContainer.slideDown();
            commentsContainer.closest('.post').attr('data-comments-loaded', 'true'); // Marca o post como carregado
        })
        .catch(() => {
            alert('Erro ao carregar os comentários.');
        })
        .finally(() => {
            hideLoading();
        });
}

function loadAllComments() {
    showLoading();
    fetch('https://jsonplaceholder.typicode.com/comments')
        .then(response => response.json())
        .then(comments => {
            const commentsByPost = {};
            comments.forEach(comment => {
                if (!commentsByPost[comment.postId]) {
                    commentsByPost[comment.postId] = [];
                }
                commentsByPost[comment.postId].push(comment);
            });

            $('.post').each(function() {
                const postId = $(this).data('post-id');
                const commentsContainer = $(this).find('.comments');

                // Verifica se os comentários já foram carregados para este post
                if ($(this).attr('data-comments-loaded') === 'false' && commentsByPost[postId]) {
                    commentsByPost[postId].forEach(comment => {
                        const commentHtml = `
                            <div class="comment">
                                <p><strong>${comment.name}</strong> (${comment.email})</p>
                                <p>${comment.body}</p>
                            </div>
                        `;
                        commentsContainer.append(commentHtml);
                    });
                    commentsContainer.slideDown();
                    $(this).attr('data-comments-loaded', 'true'); // Marca o post como carregado
                }
            });
        })
        .catch(() => {
            alert('Erro ao carregar todos os comentários.');
        })
        .finally(() => {
            hideLoading();
        });
}

$(document).ready(function() {
    loadPosts();

    $('#posts-container').on('click', '.load-comments', function() {
        const postElement = $(this).closest('.post');
        const postId = postElement.data('post-id');
        const commentsContainer = postElement.find('.comments');

        // Verifica se os comentários já foram carregados
        if (postElement.attr('data-comments-loaded') === 'false') {
            loadComments(postId, commentsContainer);
        } else {
            commentsContainer.slideToggle();
        }
    });

    $('#load-all-comments').on('click', function() {
        loadAllComments();
    });
});
