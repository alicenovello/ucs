package trabalho2;
import java.util.ArrayList;
import java.util.List;


public class Principal {
// Essa classe deve fazer o gerenciamento da aplicação, inclusive realizando cadastramentos necessários.
	

	private List<Projeto> projetos;



	
	public void carregarObjetos() {
		
		this.projetos=CarregadorDeDados.lerArquivo("C:\\Users\\alice\\Desktop\\UCS\\Programação Orientada a Objetos\\Trabalho 2\\TRABALHO_FINAL\\Lattes.txt");
		System.out.println("Objetos carregados com sucesso!");
	}
	
	//Listar os pesquisadores de uma mesma Universidade;
	
	public void listarPesquisadores(String universidade) {
	    System.out.println("Pesquisadores da UCS:");
	  
	    for (Projeto projeto : projetos) {
	        ArrayList<Aluno> participantes = projeto.getAluno();
	        ArrayList<Professor> integrantes = projeto.getProfessor();
	        
	        for (Aluno participante : participantes) {
	            if (participante.getUniversidade().equals(universidade)) {
	                System.out.println(participante);
	            }
	        }
	        
	        for (Professor integrante : integrantes) {
	            if (integrante.getUniversidade().equals(universidade)) {
	                System.out.println(integrante);
	            }
	        }
	    }
	}
	
	//Listar os autores de um determinado artigo;
	public ArrayList<Pesquisador> listarAutoresArt(String nomeArtigo) {
		
		ArrayList<Pesquisador> autores = new ArrayList<>();
	    
	    ArrayList<Artigo> artigos = new ArrayList<>();
	    
	    for (Projeto projeto : projetos) {
	        artigos.addAll(projeto.getArtigo());
	    }
	    
	    for (Artigo artigo : artigos) {
	    	      if (artigo.getTituloArt().equals(nomeArtigo)) {
	            autores.addAll(artigo.getPesquisador());
	            System.out.println("Autores do artigo " + artigo.getTituloArt() + ":");
	            for (Pesquisador autor : autores) {
	                System.out.println(autor);
	            }
	            System.out.println(artigo.getPesquisador());
	            return autores; 
	        }
	    }
	    
	    return autores; 
	}
		
	//Listar todos os projetos de um determinado pesquisador 	
	public List<Projeto> listarProjetos(String nomePesquisador) {
		List<Projeto> projetosDoPesquisador = new ArrayList<>();
		
	    for (Projeto projeto : projetos) {
	        List<Professor> professores = projeto.getProfessor();
	        ArrayList<Aluno> participantes = projeto.getAluno();
	        for (Professor professor : professores) {
	            if (professor.getNome().equals(nomePesquisador)) {
	                projetosDoPesquisador.add(projeto);
	                break;
	            }
	        }
	        for (Aluno participante : participantes) {
	        	if (participante.getNome().equals(nomePesquisador))	{
	        		projetosDoPesquisador.add(projeto);
	                break;	             
	            }
	        }
	        System.out.println(projeto.getTitulo());
	  }
	    
	    return projetosDoPesquisador;
}
	//Listar os pesquisadores de projetos já finalizados.
	public void listarPesquisadoresFim() {
		
		for (Projeto projeto : projetos) {
			ArrayList<Aluno> participantes = projeto.getAluno();
			ArrayList<Professor> integrantes = projeto.getProfessor();
			if (projeto.getDatafim()!="Atual") {
				for (Aluno participante : participantes) {
					System.out.println("Pesquisadores: "+ participante);  
				}
				for (Professor integrante : integrantes) {
					System.out.println("Pesquisadores: "+ integrante);  
	            }
				}
			}
			
		}

	public void menu() {
		int opcao = 0;
		Leitor l = new Leitor ();
		String resposta="";
		
		while (true) {

			System.out.println("1 - Carregar dados estaticos");
			System.out.println("2 - Listar os pesquisadores de uma mesma Universidade");
			System.out.println("3 - Listar os autores de um determinado artigo");
			System.out.println("4 - Listar todos os projetos de um determinado pesquisador");
			System.out.println("5 - Listar os pesquisadores de projetos ja finalizados");
			
			opcao=l.leiaInt ("Digite uma opcao");
			switch (opcao) {
			
			case 1:{
				this.carregarObjetos();
				break;
			}
			case 2:{
				System.out.print("Infore a universidade: ");
				resposta=l.leiaString(resposta);
				this.listarPesquisadores(resposta);
				break;
			}
			
			case 3:{
				System.out.print("Infore o artigo: ");
				resposta=l.leiaString(resposta);
				this.listarAutoresArt(resposta);
				break;
			}
			
			case 4:{
				System.out.print("Infore o pesquisador: ");
				resposta=l.leiaString(resposta);
				break;
			}
			case 5:{
				this.listarPesquisadoresFim();
				break;
			}
			default: System.exit(0);
			}
		}
	}
		public static void main (String args []) {
			Principal p = new Principal();
			p.menu();
		}
		
	
	
}
	
	


