package trabalho2;

import java.io.File;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;


/** 
	 * Cadastrar o título do projeto, descrição, data de início, data de final. Vincular os pesquisadores envolvidos (vetor de objetos)
	 */
public class Projeto {
	
	/**
	 * Cadastrar o título do projeto, descrição, data de início, data de final. Vincular os pesquisadores envolvidos (coleção de objetos).
	 */
	private String titulo;
	private String descricao;
	private String datainicio;
	private String datafim;
	private ArrayList<Aluno> aluno=null;
	private ArrayList<Professor> professor=null;
	private ArrayList<Artigo> artigo=null;
	protected RandomAccessFile arquivo_random;
	private String situacao;
	private String natureza;
	
	/**
	 * construtor com parâmetros
	 */
	public Projeto(String titulo, String descricao, String datainicio, String datafim, String situacao, String natureza) {
		this.titulo = titulo;
		this.descricao = descricao;
		this.datainicio = datainicio;
		this.datafim = datafim;
		this.situacao= situacao;
		this.natureza = natureza;
	}
	
	/**
	 * construtor sem parâmetros
	 */
	public Projeto() {
	
		this.titulo = "";
		this.descricao = "";
		this.datainicio = "";
		this.datafim = "";
		this.aluno = new ArrayList<Aluno>();
		this.professor= new ArrayList<Professor>();
		this.artigo= new ArrayList<Artigo>();
		this.situacao="";
		this.natureza= "";
	}
	
	/**
	 * métodos getters e setters dos atributos e vetor declarados nessa classe
	 */
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	public String getDatainicio() {
		return datainicio;
	}
	public void setDatainicio(String datainicio) {
		this.datainicio = datainicio;
	}
	public String getDatafim() {
		return datafim;
	}
	public void setDatafim(String datafim) {
		this.datafim = datafim;
	}
		
	public String getSituacao() {
		return situacao;
	}
	

	public void setSituacao(String situacao) {
		this.situacao = situacao;
	}

	public ArrayList<Aluno> getAluno() {
		return aluno;
	}

	public void setAluno(ArrayList<Aluno> aluno) {
		this.aluno.addAll(aluno);
	}

	public ArrayList<Professor> getProfessor() {
		return professor;
	}

	public void setProfessor(List<Professor> professor) {
		this.professor.addAll(professor);
	}

	public String getNatureza() {
		return natureza;
	}

	public void setNatureza(String natureza) {
		this.natureza = natureza;
	}

	public ArrayList<Artigo> getArtigo() {
		return artigo;
	}

	public void setArtigo(ArrayList<Artigo> artigo) {
		this.artigo = artigo;
	}

	/**
	 * método toString
	 */
	@Override
	public String toString() {
		return "Projeto [titulo=" + titulo + ",\n\t descricao=" + descricao + ",\n\t datainicio=" + datainicio + ",\n\t datafim="
				+ datafim + ",\n\t situacao=" + situacao + ",\n\t natureza=" + natureza + ",\n\t alunos envolvidos= " + aluno + "\n\t integrantes= " + professor + "\n\t artigo="+ artigo + "]";
	}
	
	
}
