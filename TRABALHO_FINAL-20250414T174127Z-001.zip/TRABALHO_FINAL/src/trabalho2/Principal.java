package trabalho2;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;


public class Principal {
// Essa classe deve fazer o gerenciamento da aplicação, inclusive realizando cadastramentos necessários.
	

	private List<Projeto> projetos;



	
	public void carregarObjetos() {
		
		this.projetos=CarregadorDeDados.lerArquivo("C:\\Users\\alice\\Desktop\\UCS\\Programação Orientada a Objetos\\Trabalho 2\\TRABALHO_FINAL\\Lattes.txt");
		//System.out.println(CarregadorDeDados.lerArquivo("C:\\Users\\alice\\Desktop\\UCS\\Programação Orientada a Objetos\\Trabalho 2\\TRABALHO_FINAL\\Lattes.txt"));
		System.out.println("Objetos carregados com sucesso!");
	}
	
	//Listar os pesquisadores de uma mesma Universidade;
	
	public void listarPesquisadores(String universidade, String nomeArquivo) {
	    try {
	        Arquivo arquivo = new Arquivo();
	        RandomAccessFile randomAccessFile = arquivo.criarArquivo(nomeArquivo);

	        randomAccessFile.writeUTF("Pesquisadores da UCS:");
	        randomAccessFile.writeUTF("\n");

	        for (Projeto projeto : projetos) {
	            ArrayList<Aluno> participantes = projeto.getAluno();
	            ArrayList<Professor> integrantes = projeto.getProfessor();

	            for (Aluno participante : participantes) {
	                if (participante.getUniversidade().equals(universidade)) {
	                    arquivo.escreverResultado(participante.toString());
	                    arquivo.escreverResultado("\n");
	                }
	            }

	            for (Professor integrante : integrantes) {
	                if (integrante.getUniversidade().equals(universidade)) {
	                    arquivo.escreverResultado(integrante.toString());
	                    arquivo.escreverResultado("\n");
	                }
	            }
	        }

	        arquivo.fecharArquivo();
	        System.out.println("Os pesquisadores foram salvos no arquivo: " + nomeArquivo);
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	}
	
	//Listar os autores de um determinado artigo;
	public void listarAutoresArt(String nomeArtigo, String nomeArquivo) throws IOException {
	    Arquivo arquivo = new Arquivo();
		arquivo.criarArquivo(nomeArquivo);

		ArrayList<Pesquisador> autores = new ArrayList<>();

		ArrayList<Artigo> artigos = new ArrayList<>();
		

		for (Projeto projeto : projetos) {
		    artigos.addAll(projeto.getArtigo());
		}

		for (Artigo artigo : artigos) {
			System.out.println(artigo.getTituloArt());
		    if (artigo.getTituloArt().equals(nomeArtigo)) {
		    	
		        autores.addAll(artigo.getPesquisador());

		        arquivo.escreverResultado("Autores do artigo " + artigo.getTituloArt() + ":");
		        arquivo.escreverResultado("\n");
		        for (Pesquisador autor : autores) {
		            arquivo.escreverResultado(autor.toString());
		            arquivo.escreverResultado("\n");
		        }

		        arquivo.fecharArquivo();
		        System.out.println("Os autores do artigo foram salvos no arquivo: " + nomeArquivo);
		        return;
		    }
		}

		arquivo.fecharArquivo();
		System.out.println("O artigo não foi encontrado.");
	}
		
	//Listar todos os projetos de um determinado pesquisador 	
	public void listarProjetos(String nomePesquisador, String nomeArquivo) {
	    Arquivo arquivo = new Arquivo();
		arquivo.criarArquivo(nomeArquivo);

		List<Projeto> projetosDoPesquisador = new ArrayList<>();

		for (Projeto projeto : projetos) {
		    List<Professor> professores = projeto.getProfessor();
		    List<Aluno> participantes = projeto.getAluno();
		    for (Professor professor : professores) {
		        if (professor.getNome().equals(nomePesquisador)) {
		            projetosDoPesquisador.add(projeto);
		            break;
		        }
		    }
		    for (Aluno participante : participantes) {
		        if (participante.getNome().equals(nomePesquisador)) {
		            projetosDoPesquisador.add(projeto);
		            break;
		        }
		    }
		    arquivo.escreverResultado(projeto.getTitulo());
		    arquivo.escreverResultado("\n");
		}

		arquivo.fecharArquivo();
		System.out.println("Os projetos do pesquisador foram salvos no arquivo: " + nomeArquivo);
	}
	
	
	//Listar os pesquisadores de projetos já finalizados.
	public void listarPesquisadoresFim(String nomeArquivo) throws IOException {
	    Arquivo arquivo = new Arquivo();
		arquivo.criarArquivo(nomeArquivo);

		for (Projeto projeto : projetos) {
		    ArrayList<Aluno> participantes = projeto.getAluno();
		    ArrayList<Professor> integrantes = projeto.getProfessor();
		    if (!projeto.getDatafim().equals("Atual")) {
		        for (Aluno participante : participantes) {
		            arquivo.escreverResultado("Pesquisadores: " + participante);
		            arquivo.escreverResultado("\n");
		        }
		        for (Professor integrante : integrantes) {
		            arquivo.escreverResultado("Pesquisadores: " + integrante);
		            arquivo.escreverResultado("\n");
		        }
		    }
		}

		arquivo.fecharArquivo();
		System.out.println("Os pesquisadores foram salvos no arquivo: " + nomeArquivo);
	}

	public void menu() throws IOException {
		int opcao = 0;
		Leitor l = new Leitor ();
		String resposta="";
		
		while (true) {

			System.out.println("1 - Carregar dados estaticos");
			System.out.println("2 - Listar os pesquisadores de uma mesma Universidade");
			System.out.println("3 - Listar os autores de um determinado artigo");
			System.out.println("4 - Listar todos os projetos de um determinado pesquisador");
			System.out.println("5 - Listar os pesquisadores de projetos ja finalizados");
			
			opcao=l.leiaInt ("Digite uma opcao");
			switch (opcao) {
			
			case 1:{
				this.carregarObjetos();
				break;
			}
			case 2:{
				System.out.print("Informe a universidade: ");
				resposta=l.leiaString(resposta);
				this.listarPesquisadores(resposta, "consultas");
				break;
			}
			
			case 3:{
				System.out.print("Informe o artigo: ");
				resposta=l.leiaString(resposta);
				this.listarAutoresArt(resposta, "consultas");
				break;
			}
			
			case 4:{
				System.out.print("Informe o pesquisador: ");
				resposta=l.leiaString(resposta);
				this.listarProjetos(resposta, "consultas");
				break;
			}
			case 5:{
				this.listarPesquisadoresFim("consultas");
				break;
			}
			default: System.exit(0);
			}
		}
	}
		public static void main (String args []) throws IOException {
			Principal p = new Principal();
			p.menu();
		}
		
	
	
}
	
	


