package trabalho2;

/**
 * Cadastrar o nome, a área e a universidade do pesquisador. Aplicar o conceito de herança para separar os pequisadores que são 
 * professores dos alunos.
 */

public class Pesquisador {
	/**
	 * declaração dos atributos da classe pesquisador
	 */
	private String nome;
	private String area;
	private String universidade="UCS";

	/**
	 * construtor com parâmetros
	 */
	public Pesquisador(String nome, String area, String universidade) {
		this.nome = nome;
		this.area = area;
		this.universidade = universidade;
	
	}
	
	/**
	 * construtor sem parâmetros
	 */
	public Pesquisador() {
		this.nome = "";
		this.area = "";
		this.universidade = "";
		
	}
	
	/**
	 * métodos getters e setters dos atributos declarados nessa classe
	 */
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getUniversidade() {
		return "UCS";
	}

	public void setUniversidade(String universidade) {
		this.universidade = "UCS";
	}

	/**
	 * método toString classe Pesquisador
	 */
	@Override
	public String toString() {
		return "Pesquisador [nome=" + nome + "]";
	}
	

	
	
}
	
