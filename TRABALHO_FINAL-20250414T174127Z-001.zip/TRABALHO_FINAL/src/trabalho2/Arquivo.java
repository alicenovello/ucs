package trabalho2;
import java.io.*;
/*
 * Fazer a leitura e gravação do arquivo de dados e gerenciar as exceções de manipulação de arquivos (duas no mínimo).
 */


public class Arquivo {

	    protected RandomAccessFile arquivo_random;

	    public Arquivo() {
	    }
	    
	    public RandomAccessFile criarArquivo(String pesquisadores) {
	        try {
	            File arquivo = new File(pesquisadores);
	            if(!arquivo.exists()) {
	                arquivo.createNewFile();
	            }

	            this.arquivo_random = new RandomAccessFile(arquivo, "rw");
	            
	        } catch(Exception e) {
	                e.printStackTrace();
	                System.exit(-1);
	        }
	        return this.arquivo_random;
	    }
	    public void escreverResultado(String resultado) {
	        try {
	            arquivo_random.writeUTF(resultado);
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }

	    public void fecharArquivo() {
	        try {
	            arquivo_random.close();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
	    
	}


    