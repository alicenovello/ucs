package trabalho2;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Essa classe deve fazer a carga dos valores definidos no arquivo de dados para facilitar a testagem da aplicação.
 */

public class CarregadorDeDados {

	public List <Projeto> projetos;
	
	public static void main (String args []) {
        List<Projeto> projetos = lerArquivo("C:\\Users\\alice\\Desktop\\UCS\\Programação Orientada a Objetos\\Trabalho 2\\TRABALHO_FINAL\\Lattes.txt");
               
        for (Projeto projeto : projetos) {
            System.out.println(projeto);
        }
    }
    
    public static List<Projeto> lerArquivo(String caminhoArquivo) {
        List<Projeto> projetos = new ArrayList<>();
        File file = new File(caminhoArquivo);
        
        try (Scanner scan = new Scanner(file)) {
        	 Projeto projeto = null;
            while (scan.hasNextLine()) {
                String linha = scan.nextLine();
                
                if (linha.startsWith("#Projeto")) {
                    projeto = new Projeto();
                    projetos.add(projeto);
                }
                else {
                	criarProjeto(linha, projeto);
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (Exception e) {
        	e.printStackTrace();
        }        
        return projetos;
    }
    
    public static void criarProjeto(String linha, Projeto projeto) {      
        
      
				
				if (linha.startsWith("Periodo:")) {
				   	String[] substrings = linha.split(": ");
					projeto.setDatainicio(substrings[1].split(" - ")[0]);         
					projeto.setDatafim(substrings[1].split(" - ")[1]);	
				} else if (linha.startsWith("Título:")) {
				    projeto.setTitulo(linha.substring(7));
				} else if (linha.startsWith("Descrição:")) {
				    projeto.setDescricao(linha.substring(11));
				} else if (linha.startsWith("Situação:")) {
				    projeto.setSituacao(linha.substring(10));
				} else if (linha.startsWith("Natureza:")) {
				    projeto.setNatureza(linha.substring(10));
				} else if (linha.startsWith("Alunos envolvidos:")) {
				    ArrayList<Aluno> alunos = criarListaParticipantes(linha.substring(19));
				    projeto.setAluno(alunos);
				} else if (linha.startsWith("Integrantes:")) {
				    List<Professor> professores = criarListaIntegrantes(linha.substring(12));
				    projeto.setProfessor(professores);
				} else if (linha.startsWith("Artigo:")) {
					ArrayList<Artigo> artigos=new ArrayList<Artigo>();
					Artigo artigo=criarArtigo(linha.substring(7));
					artigos.add(artigo);
				    projeto.setArtigo(artigos);
				} else if (linha.startsWith("#")) {
				    return;
				}
			}
        	
        
     
    
    public static ArrayList<Aluno> criarListaParticipantes(String linhaParticipantes) {
    	ArrayList<Aluno> participantes = new ArrayList<>();
        String[] partes = linhaParticipantes.split(", ");
        
        for (String parte : partes) {
        	Aluno aluno = new Aluno();
        	aluno.setNome(parte.trim());
        	participantes.add(aluno);
        }
        
        return participantes;
    }
    
    public static ArrayList<Professor> criarListaIntegrantes(String linhaIntegrantes) {
        ArrayList<Professor> integrantes = new ArrayList<>();
        String[] partes = linhaIntegrantes.split(" / ");
        
        for (String parte : partes) {
        	Professor professor = new Professor();
        	professor.setNome(parte.trim());
        	integrantes.add(professor);
        }
        
        return integrantes;
    }
    
    public static Artigo criarArtigo (String linhaArtigo){
    	Artigo artigo = new Artigo();
    	String[] partes = linhaArtigo.split(" \\. ");
        artigo.setPesquisador(criarPesquisadorArtigo(partes[0]));
        artigo.setTituloArt(partes[1]);
        return  artigo;   
    }
    
    public static ArrayList<Pesquisador> criarPesquisadorArtigo (String linhaPesquisadores){
    	ArrayList<Pesquisador> autores = new ArrayList<>();
    	String[] partes = linhaPesquisadores.split(";");
    	
    	for (int i=0; i<partes.length-1 ; i++) {
    		String parte = partes[i];
        	Pesquisador pesquisador = new Pesquisador();
        	pesquisador.setNome(parte.trim());
        	autores.add(pesquisador);
        }
    	
    	return autores;
    }
    
}
	

