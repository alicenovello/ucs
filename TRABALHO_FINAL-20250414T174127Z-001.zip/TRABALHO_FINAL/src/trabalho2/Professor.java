package trabalho2;

import java.util.List;

public class Professor extends Pesquisador {
	public Professor() {
		super();
		
	}
	
	public void setNome(List<String> integrantes) {
		this.setNome(integrantes);
	}



}
