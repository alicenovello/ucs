package trabalho2;
import java.util.ArrayList;
/**
 *  Cadastrar o título do artigo, ano de publicação, título da revista. Vincular os pesquisadores envolvidos (coleção de objetos).
 */
public class Artigo {
	
/**
 * declaração dos atributos da classe artigo
 */
private String tituloArt;
private int ano;
private String tituloRev;
private int auxPesquisador;
private ArrayList<Pesquisador> pesquisador=null;

/**
 * construtor com parâmetros
 */
public Artigo(String tituloArt, int ano, String tituloRev) {
	this.tituloArt = tituloArt;
	this.ano = ano;
	this.tituloRev = tituloRev;
}

/**
 * construtor sem parâmetros
 */
public Artigo() {
	this.tituloArt = "";
	this.ano = 0;
	this.tituloRev = "";
	this.auxPesquisador=0;
	this.pesquisador=new ArrayList<Pesquisador>();
}

/**
 * métodos getters e setters dos atributos declarados nessa classe
 */
public String getTituloArt() {
	return tituloArt;
}

public void setTituloArt(String tituloArt) {
	this.tituloArt = tituloArt;
}

public int getAno() {
	return ano;
}

public void setAno(int ano) {
	this.ano = ano;
}

public String getTituloRev() {
	return tituloRev;
}

public void setTituloRev(String tituloRev) {
	this.tituloRev = tituloRev;
}

public int getAuxPesquisador() {
	return auxPesquisador;
}

public void setAuxPesquisador(int auxPesquisador) {
	this.auxPesquisador = auxPesquisador;
}

public ArrayList <Pesquisador> getPesquisador() {
	return pesquisador;
}

public void setPesquisador (ArrayList<Pesquisador> pesquisador){
	this.pesquisador = pesquisador;
}

/**
 * método toString classe Artigo
 */
@Override
public String toString() {
	return "Artigo [Artigo=" + tituloArt + "Autores=" + pesquisador + "]";
}






}
