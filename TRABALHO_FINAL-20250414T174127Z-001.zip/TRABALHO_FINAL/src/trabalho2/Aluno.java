package trabalho2;

import java.util.List;

public class Aluno extends Pesquisador{
	public Aluno () {
		super();
	}
	
	public void setNome(List<String> alunos) {
		this.setNome(alunos);
	}

}
